package net.lrivas.rentacar;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import net.lrivas.rentacar.clases.ConexionSQLite;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {

    ConexionSQLite objConexion;
    final String NOMBRE_BD = "ugb2021";
    Button btnNuevo, btnBuscar;
    EditText criterio;
    ListView lista;
    ArrayList<String> miLista;
    ArrayAdapter adaptador;
    List<Integer> arregloID = new ArrayList<Integer>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        objConexion = new ConexionSQLite(MainActivity.this,NOMBRE_BD,null,1);
        lista = findViewById(R.id.lvVehiculos);

        criterio = findViewById(R.id.txtCriterio);

        btnNuevo = findViewById(R.id.btnAgregarNuevo);
        btnNuevo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Logica
                Intent mensajero = new Intent(MainActivity.this, registrar.class);
                startActivity(mensajero);
            }
        });

        btnBuscar = findViewById(R.id.btnBuscar);
        btnBuscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buscar();

            }
        });
    }

    private void buscar(){
        try{
            miLista = new ArrayList<>();

            SQLiteDatabase base = objConexion.getReadableDatabase();
            String comando = "select id_vehiculo,marca,anio from vehiculos WHERE (marca LIKE '%"+ criterio.getText() +"%' OR anio='"+ criterio.getText() +"') order by marca ASC";
            Cursor cadaRegistro = base.rawQuery(comando,null);

            arregloID.clear();
            if(cadaRegistro.moveToFirst()){
                do{
                    miLista.add(cadaRegistro.getString(1) + " - Año: "+ cadaRegistro.getString(2));
                    arregloID.add(cadaRegistro.getInt(0));
                }while(cadaRegistro.moveToNext());
            }

            adaptador = new ArrayAdapter(MainActivity.this, android.R.layout.simple_list_item_1,miLista);
            lista.setAdapter(adaptador);

        }catch (Exception error){
            Toast.makeText(MainActivity.this, "Error: "+ error.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        buscar();
    }
}
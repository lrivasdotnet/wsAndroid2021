package net.lrivas.rentacar.clases;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class ConexionSQLite extends SQLiteOpenHelper {

    final String TABLA_VEHICULOS = "" +
            "CREATE TABLE vehiculos (" +
            "id_vehiculo INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL," +
            "marca TEXT," +
            "anio INTEGER)";

    public ConexionSQLite(@Nullable  Context context, @Nullable  String name, @Nullable  SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLA_VEHICULOS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS vehiculos");
        onCreate(db);
    }
}

package net.lrivas.rentacar;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import net.lrivas.rentacar.clases.ConexionSQLite;

public class registrar extends AppCompatActivity {

    ConexionSQLite objConexion;
    final String NOMBRE_BD = "ugb2021";
    Button btnRegresar, btnRegistrar;
    EditText marca, anio;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrar);
        //Inicializar mi base de datos SQLITE
        objConexion = new ConexionSQLite(registrar.this,NOMBRE_BD,null,1);

        marca = findViewById(R.id.txtMarca);
        anio = findViewById(R.id.txtAnio);
        btnRegresar = findViewById(R.id.btnRegresarRegistro);
        btnRegresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                regresar();
            }
        });

        btnRegistrar = findViewById(R.id.btnRegistrarVehiculo);
        btnRegistrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registrar();
            }
        });
    }

    private void regresar(){
        Intent mensajero = new Intent(registrar.this, MainActivity.class);
        startActivity(mensajero);
    }

    private void registrar(){
        try{
            SQLiteDatabase bd = objConexion.getWritableDatabase();
            String comando = "INSERT INTO vehiculos (marca,anio) VALUES ('"+ marca.getText() +"','"+ anio.getText() +"')";
            bd.execSQL(comando);
            bd.close();
            Toast.makeText(registrar.this, "Contacto Registrado con exito", Toast.LENGTH_SHORT).show();
            regresar();
        }catch (Exception error){
            Toast.makeText(registrar.this, "Error interno: "+ error.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}